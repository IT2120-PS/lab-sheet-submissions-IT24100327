setwd("C:/Users/it24100327/Desktop/IT24100327")

branch_data <- read.csv("Exercise.txt", header = TRUE)

# variable type and scale of measurement for each variable

str(branch_data)

# Branch - Quantitative -	Ratio
# Sales_X1 - Quantitative -	Ratio
# Advertising_X2 - Quantitative - Ratio
# Years_X3 - Quantitative - Ratio

fix(branch_data)
attach(branch_data)

boxplot(branch_data$Sales_X1, 
        main = "Boxplot for Sales", 
        xlab = "Sales", 
        horizontal = TRUE)


summary(branch_data$Advertising_X2)
IQR(Advertising_X2)

find_outliers <- function(x) {
  q1 <- quantile(x)[2]
  q3 <- quantile(x)[4]
  iqr <- q3 - q1
  
  lb <- q1 - 1.5 * iqr
  ub <- q3 + 1.5 * iqr
  
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  print(paste("Outliers = ", paste(sort(x[x<lb | x>ub]), collapse = ",")))
  
}


find_outliers(Years_X3)



